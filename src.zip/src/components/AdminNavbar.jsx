import { useState } from "react";
import { Search, Bell, Wrench, Menu, X, LogOut } from "lucide-react";
import { useNavigate } from "react-router-dom";
import axios from "axios";

const AdminNavbar = () => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const navigate = useNavigate();

  const handleLogout = async () => {
    try {
      await axios.post(
        "http://localhost:3000/logout",
        {},
        {
          withCredentials: true,
        },
      );

      navigate("/SignIn");

      console.log("User logged out");
    } catch (err) {
      console.error("Logout failed", err);
    }
  };

  return (
    <nav className="border-b border-[#8a817c]/20 bg-[#fefeff] px-4 py-3 md:px-8">
      <div className="mx-auto flex max-w-7xl items-center justify-between">
        {/* Left: Logo */}
        <div className="flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-md bg-[#253c78] text-[#fefeff]">
            <Wrench size={18} />
          </div>
          <span className="font-sans text-xl font-semibold tracking-tight text-[#253c78]">
            electra
          </span>
        </div>

        {/* Right: Actions */}
        <div className="flex items-center gap-4">
          {/* Mobile menu toggle */}
          <button
            className="text-[#253c78] md:hidden"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            aria-label="Toggle menu"
          >
            {isMobileMenuOpen ? <X size={22} /> : <Menu size={22} />}
          </button>

          {/* Notification Bell */}
          <button
            className="relative rounded-full p-1.5 text-[#253c78] transition-colors hover:bg-[#253c78]/10"
            aria-label="Notifications"
          >
            <Bell size={20} />
            <span className="absolute -right-0.5 -top-0.5 flex h-4 w-4 items-center justify-center rounded-full bg-[#720e07] text-[10px] font-semibold text-[#fefeff]">
              3
            </span>
          </button>

          {/* Logout Button */}
          <button
            onClick={handleLogout}
            className="flex items-center gap-2 rounded-md border border-[#8a817c]/30 px-3 py-1.5 font-sans text-sm font-medium text-[#253c78] transition-colors hover:bg-[#720e07] hover:text-[#fefeff] hover:border-[#720e07]"
            aria-label="Logout"
          >
            <LogOut size={16} />
            <span className="hidden sm:inline">Logout</span>
          </button>

          {/* Avatar */}
          <div className="flex h-9 w-9 items-center justify-center rounded-full bg-[#322e18] font-sans text-sm font-medium text-[#fefeff]">
            AD
          </div>
        </div>
      </div>

      {/* Mobile Search Bar */}
      {isMobileMenuOpen && (
        <div className="mt-4 border-t border-[#8a817c]/20 pt-4 md:hidden">
          <div className="relative">
            <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
              <Search size={16} className="text-[#8a817c]" />
            </div>
            <input
              type="text"
              placeholder="Search clients, devices..."
              className="block w-full rounded-md border border-[#8a817c]/30 bg-[#fefeff] py-2 pl-10 pr-4 font-sans text-sm placeholder:text-[#8a817c]/70 focus:border-[#253c78] focus:outline-none focus:ring-1 focus:ring-[#253c78]"
            />
          </div>
        </div>
      )}
    </nav>
  );
};

export default AdminNavbar;
